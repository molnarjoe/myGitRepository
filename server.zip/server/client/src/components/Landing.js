import React from 'react';

const Landing = () => {
	return (
		<div style={{ textAlign: 'center'}}>
			<h3>My Demo Web Site</h3>
			Collect feedback from users!
		</div>
	);
};

export default Landing;
