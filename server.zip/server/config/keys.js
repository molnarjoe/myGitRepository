// keys.js commit to production server
if (process.env.NODE_ENV === 'production') {
	// production environment
	module.exports = require('./prod');
} else {
	// devlopment environment
	module.exports = require('./dev');
}
